<?php

namespace App\Http\Controllers;
use App\Shipping;
use App\Requests;
use Illuminate\Http\Request;

class ShippingController extends Controller
{
    public function Shipping(Request $req)
    {
        
    }
}
