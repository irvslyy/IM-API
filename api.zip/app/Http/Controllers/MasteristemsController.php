<?php

namespace App\Http\Controllers;
use App\ItemMaster;
use Illuminate\Http\Request;

class MasteristemsController extends Controller
{
    public function MasterItems()
    {
        
    }
}
